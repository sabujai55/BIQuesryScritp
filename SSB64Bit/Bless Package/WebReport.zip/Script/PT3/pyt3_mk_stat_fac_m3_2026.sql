Declare @dfrom  datetime 
Declare @dto  datetime
--Set @dfrom = '2026-01-01 00:00:00.000';
--Set @dto = '2026-09-30 23:59:59.999';
SELECT @dfrom=DATEADD(DAY, DATEDIFF(DAY, 0, @dd), 0)
SELECT @dto=DATEADD(MS, -3, DATEADD(DAY, DATEDIFF(DAY, 0, @dd1) + 1, 0))

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DROP TABLE IF EXISTS #Fac;

SELECT b.DischargeDateTime, 
	   a.AN AS 'AN/VN', 
	   a.HN,
	   a.FacilityRequestMethod, 
	   a.ChargeAmt,
	   a.PaidFromChargeAmt,
	   a.PaidFromDiscountAmt,
	   a.Doctor,
	   d.Clinic,
	   a.ChargeDateTime,
	   c.ARCode,
	   --c.HNReceiveCode,
	   c.InvoiceNo,
	   'I' AS 'IO'

INTO #Fac
FROM HNIPD_CHARGE AS a
INNER JOIN HNIPD_MASTER AS b ON a.an=b.an
LEFT JOIN HNIPD_INVOICE_HEADER AS c ON a.AN = c.AN AND c.InvoiceSuffixSmall = 1 
LEFT JOIN HNDOCTOR_MASTER AS d ON a.Doctor = d.Doctor 

WHERE  (a.VoidByUserCode IS NULL) AND (a.TransferVN IS NULL)
--and a.FacilityRequestMethod in (select code from dnsysconfig where ctrlcode =42161)
and b.DischargeDateTime between @dfrom and  @dto
and a.FacilityRequestMethod like 'M3%'


UNION ALL


SELECT a.VisitDate, 
	   a.VN, 
	   b.HN, 
	   a.FacilityRequestMethod,
	   a.ChargeAmt, --+(select isnull(sum(ChargeAmt),0) from dbo.HNOPD_PRESCRIP_MEDICINE where a.vn=vn and a.visitdate=visitdate and a.FacilityRequestMethod=FacilityRequestMethod and a.PrescriptionNo=PrescriptionNo)
	   a.PaidFromChargeAmt,
       a.PaidFromDiscountAmt,
	   c.Doctor,
	   c.Clinic,
	   a.ChargeDateTime, 
       d.ARCode,
	   --i.HNReceiveCode,
	   d.ReceiptNo, 
	   'O' AS 'IO'

FROM HNOPD_PRESCRIP_TREATMENT AS a 
INNER JOIN HNOPD_MASTER AS b ON a.VN=b.VN AND a.VisitDate=b.VisitDate 
INNER JOIN HNOPD_PRESCRIP AS c ON a.VN=c.VN AND a.VisitDate=c.VisitDate and a.PrescriptionNo=c.PrescriptionNo
LEFT JOIN HNOPD_RECEIVE_HEADER AS d ON a.VN=d.VN AND a.VisitDate=d.VisitDate AND d.ReceiptSuffixTiny = 1 

WHERE a.VisitDate between @dfrom and  @dto
and a.CxlDateTime IS NULL
and a.FacilityRequestMethod like 'M3%'


UNION ALL


SELECT a.VisitDate, 
	   a.VN, 
	   b.HN, 
	   a.FacilityRequestMethod,
	   a.ChargeAmt, --+(select isnull(sum(ChargeAmt),0) from dbo.HNOPD_PRESCRIP_MEDICINE where a.vn=vn and a.visitdate=visitdate and a.FacilityRequestMethod=FacilityRequestMethod and a.PrescriptionNo=PrescriptionNo)
	   a.PaidFromChargeAmt,
       a.PaidFromDiscountAmt,
	   c.Doctor,
	   c.Clinic,
	   a.ChargeDateTime, 
       d.ARCode,
	   --i.HNReceiveCode,
	   d.ReceiptNo, 
	   'O' AS 'IO'

FROM HNOPD_PRESCRIP_MEDICINE AS a
INNER JOIN HNOPD_MASTER AS b ON a.VN=b.VN AND a.VisitDate=b.VisitDate
INNER JOIN HNOPD_PRESCRIP AS c ON a.VN=c.VN AND a.VisitDate=c.VisitDate and a.PrescriptionNo=c.PrescriptionNo
LEFT JOIN HNOPD_RECEIVE_HEADER AS d ON a.VN=d.VN AND a.VisitDate=d.VisitDate AND d.ReceiptSuffixTiny = 1 

WHERE a.VisitDate between @dfrom and  @dto
and a.CxlDateTime IS NULL
and a.FacilityRequestMethod like 'M3%'

CREATE CLUSTERED INDEX IX_Fac ON #Fac (HN,FacilityRequestMethod,Clinic);



SELECT 'No'=(row_number() over (order by a.DischargeDateTime,a.[AN/VN] )),
	   a.[AN/VN] [AN/VN],
	   a.HN,
	   dbo.getname(a.hn) AS 'Name', 
	   a.FacilityRequestMethod,
	   STUFF(c.LocalName,1,1,'') AS FacName,
	   SUM(ChargeAmt) AS Amount,
	   'PaidFromChargeAMT'=sum(coalesce(paidfromchargeamt,0)),
	   'PaidFromDiscountAMT'=sum(coalesce(paidfromdiscountamt,0)),
	   'NetAMT'=sum(paidfromchargeamt)-sum(coalesce(paidfromdiscountamt,0)),
	   a.ARCode,
	   ar2.ARName ARName,
	   q2.DoctorName AS DoctorName,
	   STUFF(d.LocalName,1,1,'') AS ClinicName,
	   a.DischargeDateTime AS VisitDate,
	   a.[IO],
	   b.BirthDateTime,
	   b.Address1,
	   b.Tambon,
	   b.Amphoe,
	   b.Province,
	   b.PostalCode,
	   b.CommunicableNo,
	   a.InvoiceNo

FROM #Fac a
INNER JOIN vw_PatientMaster b ON a.hn=b.hn
LEFT JOIN DNSYSCONFIG AS c ON a.FacilityRequestMethod=c.code and c.CtrlCode='42161'
LEFT JOIN DNSYSCONFIG AS d ON a.Clinic=d.code and d.CtrlCode='42203'
LEFT JOIN ARMASTER AS ar ON a.ARCode=ar.ARCode
CROSS APPLY (
    SELECT LocalName = CASE WHEN LEN(ar.LocalName) > 0
							THEN STUFF(ar.LocalName, 1, 1, '')
							ELSE ar.LocalName
					   END,
		   EnglishName = CASE WHEN LEN(ar.EnglishName) > 0
							  THEN STUFF(ar.EnglishName, 1, 1, '')
							  ELSE ar.EnglishName
					   END
) AS ar1

CROSS APPLY (
    SELECT ARName = CASE WHEN CHARINDEX('\', ar1.LocalName) > 0
						 THEN SUBSTRING(ar1.LocalName,CHARINDEX('\', ar1.LocalName) + 1,LEN(ar1.LocalName))
                         + ' ' + LEFT(ar1.LocalName,CHARINDEX('\', ar1.LocalName) - 1)
						 ELSE ar1.LocalName
					END,
        AREnglishName = CASE WHEN CHARINDEX('\', ar1.EnglishName) > 0
							 THEN SUBSTRING(ar1.EnglishName,CHARINDEX('\', ar1.EnglishName) + 1,LEN(ar1.EnglishName))
							 + ' ' + LEFT(ar1.EnglishName,CHARINDEX('\', ar1.EnglishName) - 1)
							 ELSE ar1.EnglishName
						END
) AS ar2

LEFT JOIN HNDOCTOR_MASTER AS q ON a.Doctor=q.doctor
CROSS APPLY (
    SELECT LocalName = CASE WHEN LEN(q.localname) > 0 THEN STUFF(q.localname, 1, 1, '')
							ELSE q.localname
					   END,
           EnglishName = CASE WHEN LEN(q.englishname) > 0 THEN STUFF(q.englishname, 1, 1, '')
							  ELSE q.englishname
						 END) AS q1
CROSS APPLY (
    SELECT DoctorName = CASE WHEN CHARINDEX('\', q1.LocalName) > 0
							 THEN SUBSTRING(q1.LocalName,CHARINDEX('\', q1.LocalName) + 1,LEN(q1.LocalName))
								+ LEFT(q1.LocalName,CHARINDEX('\', q1.LocalName) - 1)
							 ELSE q1.LocalName
						END,
        DoctorEnglishName = CASE WHEN CHARINDEX('\', q1.EnglishName) > 0
								 THEN SUBSTRING(q1.EnglishName,CHARINDEX('\', q1.EnglishName) + 1,LEN(q1.EnglishName))
									+ LEFT(q1.EnglishName,CHARINDEX('\', q1.EnglishName) - 1)
								 ELSE q1.EnglishName
							END) AS q2

GROUP BY a.DischargeDateTime,a.[AN/VN],a.HN,a.FacilityRequestMethod,c.LocalName,d.LocalName,q2.DoctorName,ar2.ARName,
a.ARCode,a.[IO],b.BirthDateTime,b.Address1,b.Tambon,b.Amphoe,b.Province,b.PostalCode,b.CommunicableNo,a.InvoiceNo