Declare @dto  datetime
       ,@dfrom  datetime 
--Set @dfrom = '2018-09-01 00:00:00.000';
--Set @dto = '2018-09-01 23:59:59.999';
select  @dfrom= cast((convert(varchar(10),@dd,111)+' 00:00:00:000') as datetime)
select  @dto= cast((convert(varchar(10),@dd1,111)+' 23:59:59:997') as datetime)

select  'No'=(row_number() over (order by InvoiceDateTime,[AN/VN] )),[AN/VN],HN,NAME,HNPaccode,Packages
,ARCode,ARName,DRName,ClinicName, FromChargeAmt as 'Actual' ,'Package Price'=Amount,'Over Package'=Overpac,'VisitDate'=date,[I/O]
,InvoiceNo,EmailAddress,Nationality
from(


SELECT     a.InvoiceDateTime
			, a.AN [AN/VN]
			, b.HN
			, c.Initial + ' ' + c.FirstName + ' ' + c.LastName AS 'NAME'
			, a.InvoiceNo
			, a.FromChargeAmt
			, a.DiscountAmt
			, b.AdmDoctor
			, dbo.doctorname(b.AdmDoctor,4)AS 'DRName'
			, f.Clinic
			, dbo.sysconname(f.clinic,42203,4) AS 'ClinicName'
			, a.Cost * 0 AS 'Cost'
			, a.FromChargeAmt - a.DiscountAmt AS 'Amount'
            , 'Overpac'=(select sum(FromChargeAmt - DiscountAmt) from  dbo.HNIPD_INVOICE_HEADER aa where a.an=aa.an and LEFT(aa.InvoiceNo, 2) NOT IN ('SI', 'TI','EI') 
				AND aa.CxlByUserCode IS NULL AND  aa.HNPackageCode is NULL and  aa.PolicyNo is  null )
			, 'HNPaccode'=isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNIPD_INVOICE_HEADER where a.an=an))
			, dbo.sysconname(isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNIPD_INVOICE_HEADER where a.an=an)),43541,4) AS 'Packages'
			, a.InvoiceDateTime AS 'date'
			, a.ARCode, dbo.arname(a.ARCode,4) AS 'ARName'
			, a.HNReceiveCode
			, a.InvoiceNo AS 'InvNo'
			, 'I' AS 'I/O'
			,c.EmailAddress
			,dbo.sysconname(c.nationalitycode,10119,1) 'Nationality'
			
FROM               dbo.HNIPD_INVOICE_HEADER AS a LEFT OUTER JOIN
                      dbo.HNIPD_MASTER AS b ON a.AN = b.AN LEFT OUTER JOIN
                      dbo.MK_HN_PATIENT AS c ON b.HN = c.HN LEFT OUTER JOIN
                      dbo.HNDOCTOR_MASTER AS f ON b.AdmDoctor = f.Doctor 
where LEFT(a.InvoiceNo, 2) NOT IN ('SI', 'TI','EI') AND a.CxlByUserCode IS NULL
 AND (a.HNPackageCode IS NOT NULL or  a.[HNDiscountReasonCode] = '001' )


UNION ALL


SELECT     a.ReceiveDateTime
			, a.VN [AN/VN]	
			, b.HN
			, c.Initial + ' ' + c.FirstName + ' ' + c.LastName AS 'NAME'
			, a.ReceiptNo
			, a.FromChargeAmt
			, a.DiscountAmt
			, d.Doctor
			, dbo.doctorname(d.Doctor,4)AS 'DRName'
			, f.Clinic
			, dbo.sysconname(f.clinic,42203,4) AS 'ClinicName'
			, a.Cost * 0 AS 'Cost'
			, a.FromChargeAmt - a.DiscountAmt AS 'Amt'
            , 'Overpac'=(select sum(FromChargeAmt - DiscountAmt) from  dbo.HNOPD_RECEIVE_HEADER aa where a.VisitDate = aa.VisitDate AND a.VN = aa.VN and LEFT(aa.ReceiptNo, 2) NOT IN ('SI', 'TI','EI') 
				AND aa.CxlByUserCode IS NULL AND  aa.HNPackageCode is NULL and  aa.PolicyNo is  null )
			, 'HNPaccode'=isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNOPD_RECEIVE_HEADER where a.VisitDate = VisitDate AND a.VN = VN))
			, dbo.sysconname(isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNOPD_RECEIVE_HEADER where a.VisitDate = VisitDate AND a.VN = VN)),43541,4) AS 'Packages'
			, a.VisitDate
			, a.ARCode, dbo.arname(a.ARCode,4) AS 'ARName'
			, g.HNReceiveCode, a.ReceiptNo , 'O' AS 'I/O'
			,c.EmailAddress
			,dbo.sysconname(c.nationalitycode,10119,1) 'Nationality'

FROM         dbo.HNOPD_RECEIVE_HEADER AS a LEFT OUTER JOIN
                      dbo.HNOPD_MASTER AS b ON a.VisitDate = b.VisitDate AND a.VN = b.VN LEFT OUTER JOIN
                      dbo.MK_HN_PATIENT AS c ON b.HN = c.HN LEFT OUTER JOIN
                      dbo.HNOPD_PRESCRIP as d on (a.VisitDate = d.VisitDate AND a.VN = d.VN and a.PrescriptionNo=d.PrescriptionNo)LEFT OUTER JOIN
                      dbo.HNDOCTOR_MASTER AS f ON d.Doctor = f.Doctor LEFT OUTER JOIN
                      dbo.HNOPD_RECEIVE_BY AS g ON a.VN = g.VN AND a.VisitDate = g.VisitDate AND a.ReceiptSuffixTiny = g.ReceiptSuffixTiny AND 
                      g.SuffixTiny = 1 
where LEFT(a.ReceiptNo, 2) NOT IN ('SO', 'TO','EO') AND a.CxlByUserCode IS NULL
 AND (a.HNPackageCode IS NOT NULL or  a.[HNDiscountReasonCode] = '001' )

) jukjuk


where   InvoiceDateTime between @dfrom and @dto

