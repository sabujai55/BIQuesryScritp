Declare @dto  datetime
       ,@dfrom  datetime 
--Set @dfrom = '2018-01-01 00:00:00.000';
--Set @dto = '2018-01-10 23:59:59.999';
select  @dfrom= cast((convert(varchar(10),@dd,111)+' 00:00:00:000') as datetime)
select  @dto= cast((convert(varchar(10),@dd1,111)+' 23:59:59:997') as datetime)

select distinct 'No'=(row_number() over (order by InvoiceDateTime,[AN/VN] )),[AN/VN],HN,NAME,HNPaccode,Packages
,ARCode,ARName,DRName,ClinicName, FromChargeAmt as 'Actual' ,'Package Price'=Amount,'Over Package'=Overpac,'VisitDate'=date,[I/O]
,InvoiceNo,EmailAddress,ReceiptNo,DFDoctor,TreatmentCode,TreatmentName,DF
from(


SELECT distinct a.InvoiceDateTime
			, a.AN [AN/VN]
			, b.HN
			, c.Initial + ' ' + c.FirstName + ' ' + c.LastName AS 'NAME'
			, a.InvoiceNo
			, a.FromChargeAmt
			, a.DiscountAmt
			, b.AdmDoctor
			, dbo.doctorname(b.AdmDoctor,4)AS 'DRName'
			, f.Clinic
			, dbo.sysconname(f.clinic,42203,4) AS 'ClinicName'
			, a.Cost * 0 AS 'Cost'
			, a.FromChargeAmt - a.DiscountAmt AS 'Amount'
            , 'Overpac'=(select sum(FromChargeAmt - DiscountAmt) from  dbo.HNIPD_INVOICE_HEADER aa where a.an=aa.an and LEFT(aa.InvoiceNo, 2) NOT IN ('SI', 'TI','EI') 
				AND aa.CxlByUserCode IS NULL AND  aa.HNPackageCode is NULL and  aa.PolicyNo is  null )
			, 'HNPaccode'=isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNIPD_INVOICE_HEADER where a.an=an))
			, dbo.sysconname(isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNIPD_INVOICE_HEADER where a.an=an)),43541,4) AS 'Packages'
			, a.InvoiceDateTime AS 'date'
			, a.ARCode, dbo.arname(a.ARCode,4) AS 'ARName'
			, a.HNReceiveCode
			, a.InvoiceNo AS 'InvNo'
			, 'I' AS 'I/O'
			,c.EmailAddress
			,a.ReceiptNo
			,'DFDoctor'=dbo.doctorname(e.DFDoctor,4) 
			,d.TreatmentCode
			,'TreatmentName'=dbo.sysconname(d.TreatmentCode,42075,2)
			,'DF'=d.FromChargeAmt

FROM HNIPD_INVOICE_HEADER a 
LEFT JOIN HNIPD_MASTER b ON a.AN = b.AN 
LEFT JOIN vw_PatientMaster c ON b.HN = c.HN 
LEFT JOIN HNIPD_INVOICE_ITEM d ON a.an=d.an and a.invoicesuffixsmall=d.invoicesuffixsmall and d.treatmentcode like 'DF%'
LEFT JOIN HNIPD_CHARGE e ON a.an=e.an and d.ipdchargedatetime=e.ipdchargedatetime and d.ipdchargesuffixtiny=e.ipdchargesuffixtiny
LEFT JOIN HNDOCTOR_MASTER f ON b.AdmDoctor = f.Doctor 

WHERE LEFT(a.InvoiceNo, 2) NOT IN ('SI', 'TI','EI') AND a.CxlByUserCode IS NULL
 AND (a.HNPackageCode IS NOT NULL or  a.[HNDiscountReasonCode] = '001' )


UNION ALL


SELECT distinct a.ReceiveDateTime
			, a.VN [AN/VN]	
			, b.HN
			, c.Initial + ' ' + c.FirstName + ' ' + c.LastName AS 'NAME'
			, a.ReceiptNo
			, a.FromChargeAmt
			, a.DiscountAmt
			, d.Doctor
			, dbo.doctorname(d.Doctor,4)AS 'DRName'
			, f.Clinic
			, dbo.sysconname(f.clinic,42203,4) AS 'ClinicName'
			, a.Cost * 0 AS 'Cost'
			, a.FromChargeAmt - a.DiscountAmt AS 'Amt'
            , 'Overpac'=(select sum(FromChargeAmt - DiscountAmt) from  dbo.HNOPD_RECEIVE_HEADER aa where a.VisitDate = aa.VisitDate AND a.VN = aa.VN and LEFT(aa.ReceiptNo, 2) NOT IN ('SI', 'TI','EI') 
				AND aa.CxlByUserCode IS NULL AND  aa.HNPackageCode is NULL and  aa.PolicyNo is  null )
			, 'HNPaccode'=isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNOPD_RECEIVE_HEADER where a.VisitDate = VisitDate AND a.VN = VN))
			, dbo.sysconname(isnull(a.HNPackageCode,(select max(HNPackageCode) from dbo.HNOPD_RECEIVE_HEADER where a.VisitDate = VisitDate AND a.VN = VN)),43541,4) AS 'Packages'
			, a.VisitDate
			, a.ARCode, dbo.arname(a.ARCode,4) AS 'ARName'
			, g.HNReceiveCode, a.ReceiptNo , 'O' AS 'I/O'
			,c.EmailAddress
			,a.ReceiptNo
			,'DFDoctor'=dbo.doctorname(h.DFDoctor,4) 
			,e.TreatmentCode
			,'TreatmentName'=dbo.sysconname(e.TreatmentCode,42075,2)
			,'DF'=e.FromChargeAmt
			
FROM HNOPD_RECEIVE_HEADER a
LEFT JOIN HNOPD_MASTER b ON a.VisitDate = b.VisitDate AND a.VN = b.VN 
LEFT JOIN vw_PatientMaster c ON b.HN = c.HN 
LEFT JOIN HNOPD_PRESCRIP d ON a.VisitDate = d.VisitDate AND a.VN = d.VN and a.PrescriptionNo=d.PrescriptionNo
LEFT JOIN HNOPD_RECEIVE_ITEM e ON a.VisitDate = e.VisitDate AND a.VN = e.VN and a.ReceiptSuffixTiny=e.ReceiptSuffixTiny and e.TreatmentCode like 'DF%'
LEFT JOIN HNDOCTOR_MASTER f ON d.Doctor = f.Doctor 
LEFT JOIN HNOPD_RECEIVE_BY g ON a.VN = g.VN AND a.VisitDate = g.VisitDate AND a.ReceiptSuffixTiny = g.ReceiptSuffixTiny AND g.SuffixTiny = 1 
LEFT JOIN HNOPD_PRESCRIP_TREATMENT h ON a.VN=h.VN AND a.VisitDate=h.VisitDate AND e.SuffixSmall=h.SuffixTiny 

WHERE LEFT(a.ReceiptNo, 2) NOT IN ('SO', 'TO','EO') AND a.CxlByUserCode IS NULL
 AND (a.HNPackageCode IS NOT NULL or  a.[HNDiscountReasonCode] = '001' )

) jukjuk


where   InvoiceDateTime between @dfrom and @dto

