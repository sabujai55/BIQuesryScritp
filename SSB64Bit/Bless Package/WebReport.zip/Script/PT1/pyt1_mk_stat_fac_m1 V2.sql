Declare @dto  datetime
       ,@dfrom  datetime 
	--,@fac varchar(20)
--select  @dfrom = :dd
--select  @dto = :dd1
--select @fac =:fac
--Set @dfrom = '2025-01-01 00:00:00.000';
--Set @dto = '2025-01-31 23:59:59.999';
select  @dfrom= cast((convert(varchar(10),@dd,111)+' 00:00:00:000') as datetime)
select  @dto= cast((convert(varchar(10),@dd1,111)+' 23:59:59:997') as datetime)

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

select 'No'=(row_number() over (order by DischargeDateTime,[AN/VN] )),[AN/VN] [AN/VN],HN,Name,FacilityRequestMethod,Facname,'Amount'=sum(ChargeAmt),ARCode,ARName,DRName,ClinicName,'VisitDate'=DischargeDateTime,IO,[Patient Type],Nationality
from(
SELECT     g.DischargeDateTime, a.AN AS 'AN/VN', a.HN, b.Initial + ' ' + b.FirstName + ' ' + b.LastName AS 'NAME', a.FacilityRequestMethod, 
                      dbo.sysconname(a.FacilityRequestMethod,42161,4) AS 'Facname'
					  , a.TreatmentCode
					  , dbo.sysconname(a.TreatmentCode,42075,4)AS 'Treatmentname'
					  , a.XrayCode
					  ,dbo.sysconname(a.XrayCode,42179,4)AS 'Xrayname'
					  , a.LabCode
					  ,dbo.sysconname(a.LabCode,42179,4) AS 'Labname'
					  , a.PTModeCode,a.Cost * 0 AS 'Cost'
					  , a.ChargeAmt
					  , a.PaidFromChargeAmt
					  , a.Doctor, f.clinic,dbo.sysconname(f.clinic,42203,4) AS 'ClinicName'
					 , dbo.Doctorname(a.Doctor,4)AS 'DRName'
					 , a.ChargeDateTime
					, d.ARCode
					, dbo.arname(d.ARCode,4)AS 'ARName'
					, d.HNReceiveCode,d.InvoiceNo, 'I' AS 'IO'
					,	b.[Patient Type]
					,	b.Nationality
FROM         dbo.HNIPD_CHARGE AS a LEFT OUTER JOIN
                      dbo.MK_HN_PATIENT AS b ON a.HN = b.HN LEFT OUTER JOIN
                      dbo.HNIPD_INVOICE_HEADER AS d ON a.AN = d.AN AND d.InvoiceSuffixSmall = 1 LEFT OUTER JOIN
                      dbo.HNDOCTOR_MASTER AS f ON a.Doctor = f.Doctor LEFT OUTER JOIN
                      dbo.HNIPD_MASTER AS g ON a.an=g.an
            
WHERE  (a.VoidByUserCode IS NULL) AND (a.TransferVN IS NULL)
and a.FacilityRequestMethod in (select code from dnsysconfig where ctrlcode =42161)
UNION ALL
SELECT     a.VisitDate, a.VN, b.HN, c.Initial + ' ' + c.FirstName + ' ' + c.LastName AS 'NAME', a.FacilityRequestMethod,
   dbo.sysconname(a.FacilityRequestMethod,42161,4) AS 'Facname'
					  , a.TreatmentCode
					  , dbo.sysconname(a.TreatmentCode,42075,4)AS 'Treatmentname'
					  , a.XrayCode
					  ,dbo.sysconname(a.XrayCode,42179,4)AS 'Xrayname'
					  , a.LabCode
					  ,dbo.sysconname(a.LabCode,42179,4) AS 'Labname'
					  , a.PTModeCode, a.StandardCost * 0 AS 'Cost'
	                 , a.ChargeAmt--+(select isnull(sum(ChargeAmt),0) from dbo.HNOPD_PRESCRIP_MEDICINE where a.vn=vn and a.visitdate=visitdate and a.FacilityRequestMethod=FacilityRequestMethod and a.PrescriptionNo=PrescriptionNo)
                     , a.PaidFromChargeAmt, 
                      f.Doctor, f.Clinic,dbo.sysconname(g.clinic,42203,4) AS 'ClinicName'
                   , dbo.Doctorname(f.Doctor,4)AS 'DRName', a.ChargeDateTime, 
                      e.ARCode,  dbo.arname(e.ARCode,4)AS 'ARName', i.HNReceiveCode, e.ReceiptNo, 'O' AS 'IO'
					 ,	c.[Patient Type]
					,	c.Nationality
FROM                  dbo.HNOPD_PRESCRIP_TREATMENT AS a LEFT OUTER JOIN
                      dbo.HNOPD_MASTER AS b ON a.VN = b.VN AND a.VisitDate = b.VisitDate LEFT OUTER JOIN
                      dbo.MK_HN_PATIENT AS c ON b.HN = c.HN LEFT OUTER JOIN
                      dbo.HNOPD_RECEIVE_HEADER AS e ON a.VN = e.VN AND a.VisitDate = e.VisitDate AND e.ReceiptSuffixTiny = 1 LEFT OUTER JOIN
		             dbo.HNOPD_PRESCRIP	 as f on ( a.vn=f.vn and a.visitdate=f.visitdate  and a.PrescriptionNo=f.PrescriptionNo)LEFT OUTER JOIN
                      dbo.HNDOCTOR_MASTER AS g ON f.Doctor = g.Doctor LEFT OUTER JOIN
                      dbo.HNOPD_RECEIVE_BY AS i ON e.VN = i.VN AND e.VisitDate = i.VisitDate AND e.ReceiptSuffixTiny = i.ReceiptSuffixTiny AND
                      i.SuffixTiny = 1 
WHERE      a.FacilityRequestMethod in (select code from dnsysconfig where ctrlcode =42161) AND (a.CxlByUserCode IS NULL)


union all

SELECT     a.VisitDate, a.VN, b.HN, c.Initial + ' ' + c.FirstName + ' ' + c.LastName AS 'NAME', a.FacilityRequestMethod,
   dbo.sysconname(a.FacilityRequestMethod,42161,4) AS 'Facname'
					  , a.stockcode
					  , ''
					  , ''
					  ,''AS 'Xrayname'
					  ,''
					  ,'' AS 'Labname'
					  , '',  0 AS 'Cost'
	                 , a.ChargeAmt--+
                     , a.PaidFromChargeAmt, 
                      f.Doctor, f.Clinic,dbo.sysconname(g.clinic,42203,4) AS 'ClinicName'
                   , dbo.Doctorname(f.Doctor,4)AS 'DRName', a.ChargeDateTime, 
                      e.ARCode,  dbo.arname(e.ARCode,4)AS 'ARName', i.HNReceiveCode, e.ReceiptNo, 'O' AS 'IO'
					,	c.[Patient Type]
					,	c.Nationality
FROM                  dbo.HNOPD_PRESCRIP_MEDICINE AS a LEFT OUTER JOIN
                      dbo.HNOPD_MASTER AS b ON a.VN = b.VN AND a.VisitDate = b.VisitDate LEFT OUTER JOIN
                      dbo.MK_HN_PATIENT AS c ON b.HN = c.HN LEFT OUTER JOIN
                      dbo.HNOPD_RECEIVE_HEADER AS e ON a.VN = e.VN AND a.VisitDate = e.VisitDate AND e.ReceiptSuffixTiny = 1 LEFT OUTER JOIN
		             dbo.HNOPD_PRESCRIP	 as f on ( a.vn=f.vn and a.visitdate=f.visitdate  and a.PrescriptionNo=f.PrescriptionNo)LEFT OUTER JOIN
                      dbo.HNDOCTOR_MASTER AS g ON f.Doctor = g.Doctor LEFT OUTER JOIN
                      dbo.HNOPD_RECEIVE_BY AS i ON e.VN = i.VN AND e.VisitDate = i.VisitDate AND e.ReceiptSuffixTiny = i.ReceiptSuffixTiny AND
                      i.SuffixTiny = 1 
WHERE      a.FacilityRequestMethod in (select code from dnsysconfig where ctrlcode =42161) AND (a.CxlByUserCode IS NULL)


) jukjuk 
where DischargeDateTime between @dfrom and  @dto
and  FacilityRequestMethod like 'M1%'--@fac
group by  [AN/VN],HN,NAME,FacilityRequestMethod,Facname,ARCode,ARName,DRName,ClinicName,DischargeDateTime,IO,[Patient Type],Nationality
